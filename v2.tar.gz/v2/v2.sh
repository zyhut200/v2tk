#!/bin/bash

# 随机端口号，5位
function rand_port()
{
    while true
    do
        while true
        do
      head_num=`mkpasswd -l 1 -s 0 -c 0 -C 0 -d 1`
      if [ $head_num -gt 6 ]; then
        continue
      elif [ $head_num == 0 ]; then
        continue
      else
        break
      fi
        done


        while true
        do
                foo_port=`mkpasswd -l 4 -s 0 -c 0 -C 0 -d 4`
                if [ $foo_port -gt 5000 ]; then
                        continue
                else
                        break
                fi
        done

    final_port=$head_num$foo_port

        c=`netstat -tnlp | grep $final_port | wc -l`
        if [ $c != 0 ]; then
                continue
        else
                break
        fi

    done

    echo $final_port
}

pkill -9 v2ray
rm -rf /home/v2ray

if [ ! -e "/usr/bin/unzip" ]; then
  yum install -y unzip
fi

if [ ! -e "./v2ray-linux-64.zip" ]; then
  echo "v2ray-linux-64.zip 安装包不存在，退出安装！"
  exit
fi

unzip v2ray-linux-64.zip -d /home/v2ray
rm -f v2ray-linux-64.zip

rm -f /home/v2ray/config.json

echo "获取系统内ip并导入到当前目录下的 ip 文件中"
hostname -I | sed 's/ /\n/g' | sed '/^\s*$/d' | grep -v 192.168.18.1 | grep -v ":" > ip
echo "ip获取完成，查看ip文件是否需要删减。"

if [ ! -e "/usr/bin/wget" ]; then
  yum install -y wget
fi

if [ ! -e "/usr/bin/netstat" ]; then
  yum install -y net-tools
fi

if [ ! -e /usr/bin/mkpasswd ];then
  yum install -y expect
fi

if [ ! -e /usr/bin/expr ];then
  yum install -y coreutils
fi


ulimit -SHc unlimited
ulimit -SHn 102400
ulimit -SHs unlimited
ulimit -SHu unlimited

cat <<EOF > /etc/security/limits.d/20-nproc.conf
# nproc
*       soft    nproc   65535
root    soft    nproc   unlimited
*       hard    nproc   65535
root    hard    nproc   unlimited

# nofile
*       soft    nofile   102400
root    soft    nofile   102400
*       hard    nofile   102400
root    hard    nofile   102400

# core
*       soft    core     unlimited
root    soft    core     unlimited
*       hard    core     unlimited
root    hard    core     unlimited

# stack
*       soft    stack    unlimited
root    soft    stack    unlimited
*       hard    stack    unlimited
root    hard    stack    unlimited
EOF

c=`cat /etc/systemd/system.conf | grep -w "DefaultLimitCORE=infinity" | wc -l`
if [ $c == 0 ]; then
    echo "DefaultLimitCORE=infinity" >> /etc/systemd/system.conf
fi

c=`cat /etc/systemd/system.conf | grep -w "DefaultLimitNOFILE=102400" | wc -l`
if [ $c == 0 ]; then
    echo "DefaultLimitNOFILE=102400" >> /etc/systemd/system.conf
fi

c=`cat /etc/systemd/system.conf | grep -w "DefaultLimitNPROC=unlimited" | wc -l`
if [ $c == 0 ]; then
    echo "DefaultLimitNPROC=unlimited" >> /etc/systemd/system.conf
fi

c=`cat /etc/systemd/system.conf | grep -w "DefaultLimitSTACK=unlimited" | wc -l`
if [ $c == 0 ]; then
    echo "DefaultLimitSTACK=unlimited" >> /etc/systemd/system.conf
fi

systemctl daemon-reexec

if [ ! -d /home/v2ray/config ]; then
   mkdir /home/v2ray/config
fi

if [ ! -d /var/log/v2ray ]; then
   mkdir /var/log/v2ray
fi

tag_start_num=1
cat /dev/null > /tmp/temp_account

while read line || [[ -n ${line} ]]
do

uuid=`/home/v2ray/v2ctl uuid`
port=`rand_port`

rm -f /home/v2ray/config/$line.json

echo "创建第 $tag_start_num 个"
cat <<EOF >> /home/v2ray/config/$tag_start_num.json
{
  "log": {
    "access": "/var/log/v2ray/access.log",
    "error": "/var/log/v2ray/error.log",
    "loglevel": "warning"
  },
  
  
  "inbounds": [
    {
      "port": $port,
      "listen":"$line",
      "protocol": "vmess",
      "settings": {
        "clients": [
          {
            "id":"$uuid",
            "level": 1,
            "alterId": 64
          }
        ]
      },
      "streamSettings": {
        "network": "tcp"
      },
      "sniffing": {
        "enabled": true,
        "destOverride": [
          "http",
          "tls"
        ]
      },
      "tag":"in$tag_start_num"
    }
    //include_ss
    //include_socks
    //include_mtproto
    //include_in_config
    //
  ],
  
  
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {
        "domainStrategy": "UseIP"
      },
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "settings": {},
      "tag": "blocked"
        },
      {
      "sendThrough":"$line",
      "protocol":"freedom",
      "settings": {},
      "tag":"out$tag_start_num"
        }
    //include_out_config
    //
  ],
  
  
  "dns": {
    "servers": [
      "https+local://dns.google/dns-query",
      "8.8.8.8",
      "1.1.1.1",
      "localhost"
    ]
  },
  "routing": {
    "domainStrategy": "IPOnDemand",
    "rules": [
                {
                  "type": "field",
                  "port": 53,
                  "outboundTag": "direct"
                },
                {
                  "type": "field",
                  "domain": [
                      "regexp:.*security.*"
                    ],
                  "outboundTag": "direct"
                },
                {
                  "type": "field",
                  "domain": [
                      "regexp:.*login.*"
                    ],
                  "outboundTag": "direct"
                },
                {
                  "type": "field",
                  "domain": [
                    "regexp:.*pull.*",
                    "regexp:.*log.*",
                    "regexp:v16m.*",
                    "regexp:v19.*",
                    "regexp:^[a-zA-Z]{1}[0-9]{2}.*"
                  ],
                  "outboundTag": "blocked"
                },
                {
                  "type": "field",
                  "network": "udp",
                  "outboundTag": "blocked"
                },
                {
                  "type": "field",
                  "ip": [
                      "geoip:private"
                    ],
                  "outboundTag": "blocked"
                },
                {
                  "type": "field",
                  "domain": [
                    "domain:epochtimes.com",
                    "domain:epochtimes.com.tw",
                    "domain:epochtimes.fr",
                    "domain:epochtimes.de",
                    "domain:epochtimes.jp",
                    "domain:epochtimes.ru",
                    "domain:epochtimes.co.il",
                    "domain:epochtimes.co.kr",
                    "domain:epochtimes-romania.com",
                    "domain:erabaru.net",
                    "domain:lagranepoca.com",
                    "domain:theepochtimes.com",
                    "domain:ntdtv.com",
                    "domain:ntd.tv",
                    "domain:ntdtv-dc.com",
                    "domain:ntdtv.com.tw",
                    "domain:minghui.org",
                    "domain:renminbao.com",
                    "domain:dafahao.com",
                    "domain:dongtaiwang.com",
                    "domain:falundafa.org",
                    "domain:wujieliulan.com",
                    "domain:ninecommentaries.com",
                    "domain:shenyun.com"
                  ],
                  "outboundTag": "blocked"
                },
                {
                  "type": "field",
                  "protocol": [
                      "bittorrent"
                    ],
                  "outboundTag": "blocked"
                },
                {
                  "type":"field",
                  "inboundTag":"in$tag_start_num",
                  "outboundTag":"out$tag_start_num"
                }
      //include_ban_ad
      //include_rules
      //
    ]
  },
  "transport": {
    "kcpSettings": {
            "uplinkCapacity": 100,
            "downlinkCapacity": 100,
            "congestion": true
        }
  }
}
EOF

line=`curl -s --connect-timeout 10 --interface $line -A "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.62" http://whatismyip.akamai.com`
cat <<EOF > /tmp/v2tmp
{
  "v": "2",
  "ps": "ip$tag_start_num",
  "add": "$line",
  "port": "$port",
  "id": "$uuid",
  "aid": "64",
  "net": "tcp",
  "type": "none",
  "host": "",
  "path": "",
  "tls": ""
}
EOF
ma=`cat /tmp/v2tmp | base64 -w 0`

echo "vmess://$ma" >> /tmp/temp_account
tag_start_num=`expr $tag_start_num + 1`

done < ip

echo "pkill -9 v2ray" > /home/v2ray/stop.sh
echo 'ls /home/v2ray/config/ | xargs -I filename sh -c "nohup /home/v2ray/v2ray -c /home/v2ray/config/filename > /dev/null 2>&1 &"' > /home/v2ray/start.sh
echo 'sleep 1' >> /home/v2ray/start.sh
chmod 700 /home/v2ray/stop.sh
chmod 700 /home/v2ray/start.sh
sh /home/v2ray/stop.sh
sh /home/v2ray/start.sh

cat /dev/null > account.txt
cat /tmp/temp_account | column -t > account.txt
rm -f /tmp/temp_account
rm -f /tmp/v2tmp

cat ./account.txt

systemctl stop firewalld
systemctl disable firewalld
systemctl stop iptables
systemctl disable iptables

echo ""
echo "启动start.sh、关闭stop.sh脚本位于 /home/v2ray 目录下"
echo "账号文件位于当前目录下的 account.txt 中"
echo "安装完成"